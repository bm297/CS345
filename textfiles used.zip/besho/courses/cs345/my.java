public class my{

	public static void main(String[] args){

		System.out.printf("Hello");

	}

}
